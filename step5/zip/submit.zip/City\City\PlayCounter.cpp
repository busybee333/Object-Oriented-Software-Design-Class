/**
 * \file PlayCounter.cpp
 *
 * \author Romi Yun
 */

#include "stdafx.h"
#include "PlayCounter.h"
#include "MichiganFan.h"

 /**
  * Constructor
  */
CPlayCounter::CPlayCounter()
{
}

/**
 * Destructor
 */
CPlayCounter::~CPlayCounter()
{
}

/** Visit a CPlayCounter object
* \param fan Fan we are visiting */
void CPlayCounter::VisitMichiganFan(CMichiganFan *fan)
{
	fan->IncrementPlay();
	fan->ChangeState();
	mNumFans++;
}
