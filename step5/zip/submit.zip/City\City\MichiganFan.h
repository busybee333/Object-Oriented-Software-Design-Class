/**
* \file MichiganFan.h
*
* \author Romi Yun
*
*  Class that implements a Michigan fan
*/

#pragma once

#include "Tile.h"
#include "TileVisitor.h"

/**
*  A Michigan fan on a tile
*/
class CMichiganFan : public CTile
{
public:
	CMichiganFan(CCity *city);

	///  Default constructor (disabled)
	CMichiganFan() = delete;

	///  Copy constructor (disabled)
	CMichiganFan(const CMichiganFan &) = delete;

	~CMichiganFan();

	virtual std::shared_ptr<xmlnode::CXmlNode> XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node) override;

	void LoadImage(std::unique_ptr<Gdiplus::Bitmap>& image, std::wstring name);

	void Draw(Gdiplus::Graphics * graphics);

	void ChangeState();

	void IncrementPlay();

	/** Accept a visitor
	 * \param visitor The visitor we accept */
	virtual void Accept(CTileVisitor *visitor) override { visitor->VisitMichiganFan(this); }

	enum States { Beginning, During };

private:
	/// The image of the left pointing hand
	std::unique_ptr<Gdiplus::Bitmap> mBeginningFan;

	/// The image of the right pointing hand
	std::unique_ptr<Gdiplus::Bitmap> mDuringFan;

	States mState = Beginning;

	int mNumPlays = 0;
};