/**
 * \file CPlayCounter.h
 *
 * \author Romi Yun
 *
 *  Class that implements a concrete visitor to count plays.
 */

#pragma once
#include "TileVisitor.h"

 /**
 *  A play counter counter
 */
class CPlayCounter :
	public CTileVisitor
{
public:
	CPlayCounter();
	virtual ~CPlayCounter();

	virtual void VisitMichiganFan(CMichiganFan * fan) override;

	/** Get the number of fans
	 * \returns Number of fans */
	int GetNumFans() const { return mNumFans; }

private:
	int mNumFans = 0;
};
