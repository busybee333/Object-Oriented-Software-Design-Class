/**
 * \file Animal.cpp
 *
 * \author Romi Yun
 */

#include "pch.h"
#include <iostream>
#include "Animal.h"

/** Constructor.
 */
CAnimal::CAnimal()
{
}

/** Destructor.
 */
CAnimal::~CAnimal()
{
}

