/**
 * \file TileVisitor.cpp
 *
 * \author Romi Yun
 */

#include "stdafx.h"
#include "TileVisitor.h"

 /**
  * Constructor
  */
CTileVisitor::CTileVisitor()
{
}

/**
 * Destructor
 */
CTileVisitor::~CTileVisitor()
{
}
