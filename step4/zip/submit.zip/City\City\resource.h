//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by City.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_CityTYPE                    130
#define IDB_TOOLBARH                    313
#define IDB_TBGRASS                     314
#define IDB_TBROAD                      315
#define IDD_TILEEDITDLG                 316
#define IDC_COMBO1                      1000
#define IDC_ZONING                      1001
#define ID_FILE_OPEN32771               32771
#define ID_FILE_SAVEAS                  32772
#define ID_ADDTILES_GRASS               32773
#define ID_BUILDINGS_FARMHOUSE          32774
#define ID_GRA                          32775
#define ID_LANDSCAPING                  32776
#define ID_LANDSCAPING_GRASS            32777
#define ID_LANDSCAPING_SPARTYSTATUE     32778
#define ID_BUILDINGS_BLACKSMITHSHOP     32780
#define ID_LANDSCAPING_TALLGRASS        32781
#define ID_BUILDINGS_BROWNHOUSE         32782
#define ID_BUILDINGS_YELLOWHOUSE        32783
#define ID_BUILDINGS_F                  32784
#define ID_BUILDINGS_HOSPITAL           32785
#define ID_BUILDINGS_MARKET             32786
#define ID_BUILDINGS_CONDOS             32787
#define ID_LANDSCAPING_TREE             32788
#define ID_LANDSCAPING_TREES            32789
#define ID_LANDSCAPING_BIGTREES         32790
#define ID_LANDSCAPING_ROAD             32791
#define ID_BUSINESSES_COALMINE          32793
#define ID_BUILDINGS_COUNT              32794
#define ID_BIGTEN_MICHIGANFAN           32795
#define ID_BIGTEN_PLAY                  32796
#define ID_BIGTEN_NEWSEASON             32797
#define ID_BIGTEN_RUNAWAY               32798
#define ID_VIEW_MOUSETRACKS             32799

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        317
#define _APS_NEXT_COMMAND_VALUE         32800
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
